import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

  class Questions {
  private static final ArrayList<String> questions = new ArrayList<String>();
  private static final HashMap<String, String> questionAnswerMap = new HashMap<String, String>();
    
    static {
        questions.add("What weapon do Jedi use?");
        questions.add("What is the real name of Baby Yoda?");
        questions.add("What tiny animal-like things live on Endor?");
        // questions.add("");
        // questions.add("");
        // questions.add("");
        // questions.add("");

      questionAnswerMap.put("What weapon do Jedi use?", "Lightsabers");
      questionAnswerMap.put("What is the real name of Baby Yoda", "Grogu");
      questionAnswerMap.put("What tiny animal-like things live on Endor?", "Ewoks");
      // questionAnswerMap.put("", "");
      // questionAnswerMap.put("", "");
      // questionAnswerMap.put("", "");
      // questionAnswerMap.put("", "");
      // questionAnswerMap.put("", "");
      // questionAnswerMap.put("", "");
    }
  public static String generateRandomQuestion() {
      Random rand = new Random();
      return questions.get(rand.nextInt(questions.size()));
  }

    public static String getAnswerForQuestion(String question) {
        return questionAnswerMap.get(question);
    }
    
    }